//
// Generated file. Do not edit.
// This file is generated from template in file `flutter_tools/lib/src/flutter_plugins.dart`.
//

// @dart = 3.5

import 'dart:io'; // flutter_ignore: dart_io_import.
import 'package:open_file_android/open_file_android.dart';
import 'package:sqflite_android/sqflite_android.dart';
import 'package:open_file_ios/open_file_ios.dart';
import 'package:sqflite_darwin/sqflite_darwin.dart';
import 'package:open_file_linux/open_file_linux.dart';
import 'package:open_file_mac/open_file_mac.dart';
import 'package:sqflite_darwin/sqflite_darwin.dart';
import 'package:open_file_windows/open_file_windows.dart';

@pragma('vm:entry-point')
class _PluginRegistrant {

  @pragma('vm:entry-point')
  static void register() {
    if (Platform.isAndroid) {
      try {
        OpenFileAndroid.registerWith();
      } catch (err) {
        print(
          '`open_file_android` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

      try {
        SqfliteAndroid.registerWith();
      } catch (err) {
        print(
          '`sqflite_android` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isIOS) {
      try {
        OpenFileIOS.registerWith();
      } catch (err) {
        print(
          '`open_file_ios` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

      try {
        SqfliteDarwin.registerWith();
      } catch (err) {
        print(
          '`sqflite_darwin` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isLinux) {
      try {
        OpenFileLinux.registerWith();
      } catch (err) {
        print(
          '`open_file_linux` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isMacOS) {
      try {
        OpenFileMac.registerWith();
      } catch (err) {
        print(
          '`open_file_mac` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

      try {
        SqfliteDarwin.registerWith();
      } catch (err) {
        print(
          '`sqflite_darwin` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    } else if (Platform.isWindows) {
      try {
        OpenFileWindows.registerWith();
      } catch (err) {
        print(
          '`open_file_windows` threw an error: $err. '
          'The app may not function as expected until you remove this plugin from pubspec.yaml'
        );
      }

    }
  }
}
